import http from "../http-common";

class AuthService {
  login() {
    return http.get("/login");
  }
}

export default new AuthService();