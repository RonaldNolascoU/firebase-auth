<template>
  <v-app>
    <v-container class="grey lighten-5">
      <v-card
      class="mx-auto"
      max-width="800"
      elevation="2"
    >Login
    <v-row
        class="mb-6"
        no-gutters
      >
        <v-col md="6">
          <v-card
            class="pa-2"
            outlined
            tile
          >
            .col-md-6
          </v-card>
        </v-col>
        <v-col
          md="6"
        >
          <v-card
            class="pa-2"
            outlined
            tile
          >
          <v-img
  lazy-src="https://picsum.photos/id/11/10/6"
  max-height="150"
  max-width="250"
  src="https://picsum.photos/id/11/500/300"
></v-img>
          </v-card>
        </v-col>
      </v-row>
</v-card>
      
    </v-container>
  </v-app>
</template>

<script>
  export default {
    data: () => ({
      valid: true,
      name: '',
      nameRules: [
        v => !!v || 'Name is required',
        v => (v && v.length <= 10) || 'Name must be less than 10 characters',
      ],
      email: '',
      emailRules: [
        v => !!v || 'E-mail is required',
        v => /.+@.+\..+/.test(v) || 'E-mail must be valid',
      ],
      select: null,
      items: [
        'Item 1',
        'Item 2',
        'Item 3',
        'Item 4',
      ],
      checkbox: false,
    }),

    methods: {
      validate () {
        this.$refs.form.validate()
      },
      reset () {
        this.$refs.form.reset()
      },
      resetValidation () {
        this.$refs.form.resetValidation()
      },
    },
  }
</script>